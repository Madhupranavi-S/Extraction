"""
detector_singlestage_sahi_v1.py
================================
Eval-harness wrapper for the SINGLE-STAGE canthus model (best.pt / detect.pt)
using FIXED-TILE SAHI slicing.

Source: extracted from the original live "Thermal Health Monitor" script.
Everything camera-specific (guideusb2 capture loop, BME280 ambient sensor,
fever classification/streak logic, debug display, CSV logging) has been
stripped out — none of it affects canthus *point localization*, which is
all this harness measures. Only the actual detection math survives,
unchanged from the original.

NOTE ON THIS VARIANT: this is the EARLIER/fixed-tile config (96x72px tiles,
flat 2.0x upscale, same geometry regardless of subject distance). A later
iteration (see detector_singlestage_sahi_v2_cascade.py) identified this
fixed tiling as mismatched against the model's actual training crop scale
(300x300, face-filling) and replaced it with a multi-scale cascade. Keeping
both as separate detectors is exactly the point of this harness — let the
metrics show which one actually wins, rather than assuming the "fix" helped.

Interface
---------
load_models(weights_path=None) -> model
detect(model, bgr) -> {
    "left_pt":  (x, y) or None,
    "right_pt": (x, y) or None,
    "left_conf":  float,
    "right_conf": float,
}
Either point being None is the EXPECTED way to signal "not found" — that's
what occluded_side_false_positive_rate in eval_harness.py is measuring.

If your real eval_harness.py expects a different call shape (e.g. a plain
tuple return, or a function named load_model() singular), only the bottom
two functions need to change — everything above is the actual detector.
"""

from pathlib import Path
import numpy as np
import cv2

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None  # allows this file to be imported/tested without ultralytics installed

# =============================================================
# MODEL CONFIG (unchanged from source)
# =============================================================
CLASS_LEFT  = 0
CLASS_RIGHT = 1
CONF_THRESH = 0.25
IMG_SIZE    = 320   # imgsz fed to the model per-slice

# --- SAHI slicing geometry (fixed, distance-agnostic) ---
SAHI_SLICE_H = 72
SAHI_SLICE_W = 96
SAHI_OVERLAP = 0.35
SAHI_MERGE_IOU = 0.3
SAHI_UPSCALE = 2.0

# Set True to get the original per-slice detection print statements.
# Off by default — with 100+ eval images x dozens of slices each, this
# would otherwise flood stdout for no benefit during batch evaluation.
VERBOSE = False


def _preprocess(img_bgr: np.ndarray) -> np.ndarray:
    """Match training pipeline: IronRed images directly, no extra contrast steps."""
    return img_bgr


def _make_slices(width: int, height: int):
    """Generate overlapping (x1, y1, x2, y2) slice boxes covering the full frame."""
    stride_x = max(1, int(SAHI_SLICE_W * (1 - SAHI_OVERLAP)))
    stride_y = max(1, int(SAHI_SLICE_H * (1 - SAHI_OVERLAP)))

    xs = list(range(0, max(width - SAHI_SLICE_W, 0) + 1, stride_x))
    ys = list(range(0, max(height - SAHI_SLICE_H, 0) + 1, stride_y))
    if not xs or xs[-1] != max(width - SAHI_SLICE_W, 0):
        xs.append(max(width - SAHI_SLICE_W, 0))
    if not ys or ys[-1] != max(height - SAHI_SLICE_H, 0):
        ys.append(max(height - SAHI_SLICE_H, 0))

    slices = []
    for y1 in ys:
        y2 = min(y1 + SAHI_SLICE_H, height)
        y1 = max(0, y2 - SAHI_SLICE_H)
        for x1 in xs:
            x2 = min(x1 + SAHI_SLICE_W, width)
            x1 = max(0, x2 - SAHI_SLICE_W)
            slices.append((x1, y1, x2, y2))
    return slices


def _iou(box_a, box_b) -> float:
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)

    inter_w = max(0.0, inter_x2 - inter_x1)
    inter_h = max(0.0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h
    if inter_area <= 0:
        return 0.0

    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter_area
    if union <= 0:
        return 0.0
    return inter_area / union


def _nms_merge(dets):
    """Greedy NMS collapsing duplicate detections from overlapping slices."""
    if not dets:
        return []
    dets = sorted(dets, key=lambda d: d[1], reverse=True)
    kept = []
    used = [False] * len(dets)

    for i, (box_i, conf_i) in enumerate(dets):
        if used[i]:
            continue
        kept.append((box_i, conf_i))
        for j in range(i + 1, len(dets)):
            if used[j]:
                continue
            box_j, _ = dets[j]
            if _iou(box_i, box_j) > SAHI_MERGE_IOU:
                used[j] = True
    return kept


def _single_stage_detect(model, bgr: np.ndarray):
    """
    SAHI-style sliced inference for the single-stage canthus model.
    Returns (left_pt, right_pt, left_conf, right_conf) in full-frame
    pixel coords. Either point may be None if not found anywhere.
    """
    prepped = _preprocess(bgr)
    h, w = prepped.shape[:2]

    left_dets  = []
    right_dets = []

    for (x1, y1, x2, y2) in _make_slices(w, h):
        patch = prepped[y1:y2, x1:x2]
        if patch.size == 0:
            continue

        if SAHI_UPSCALE != 1.0:
            patch_in = cv2.resize(
                patch, None, fx=SAHI_UPSCALE, fy=SAHI_UPSCALE,
                interpolation=cv2.INTER_CUBIC)
        else:
            patch_in = patch

        results = model(patch_in, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]

        if VERBOSE and results.boxes is not None and len(results.boxes) > 0:
            print(f"slice ({x1},{y1})-({x2},{y2}): "
                  f"max_conf={results.boxes.conf.max():.3f}, "
                  f"cls={results.boxes.cls.cpu().numpy().astype(int).tolist()}")

        if results.boxes is None or len(results.boxes) == 0:
            continue

        boxes = results.boxes.xyxy.cpu().numpy()
        clss  = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()

        for box, cls_id, conf in zip(boxes, clss, confs):
            full_box = (
                float(box[0] / SAHI_UPSCALE + x1),
                float(box[1] / SAHI_UPSCALE + y1),
                float(box[2] / SAHI_UPSCALE + x1),
                float(box[3] / SAHI_UPSCALE + y1),
            )
            if cls_id == CLASS_LEFT:
                left_dets.append((full_box, float(conf)))
            elif cls_id == CLASS_RIGHT:
                right_dets.append((full_box, float(conf)))

    left_dets  = _nms_merge(left_dets)
    right_dets = _nms_merge(right_dets)

    left_pt  = None
    right_pt = None
    left_conf  = 0.0
    right_conf = 0.0

    if left_dets:
        (lx1, ly1, lx2, ly2), left_conf = max(left_dets, key=lambda d: d[1])
        left_pt = (float((lx1 + lx2) / 2.0), float((ly1 + ly2) / 2.0))

    if right_dets:
        (rx1, ry1, rx2, ry2), right_conf = max(right_dets, key=lambda d: d[1])
        right_pt = (float((rx1 + rx2) / 2.0), float((ry1 + ry2) / 2.0))

    return left_pt, right_pt, left_conf, right_conf


# =============================================================
# PUBLIC HARNESS INTERFACE
# =============================================================
_DEFAULT_WEIGHT_CANDIDATES = [
    Path("thermal-canthus-detector") / "detect.pt",
    Path("detect.pt"),
    Path.home() / "thermal-canthus-detector" / "detect.pt",
]


def load_models(weights_path=None):
    """
    Load the single-stage YOLO canthus model.
    weights_path: str/Path to the .pt file, or None to try the same
    auto-detect candidates the original live script used.
    """
    if YOLO is None:
        raise ImportError("ultralytics is required: pip install ultralytics")

    if weights_path:
        path = Path(weights_path)
    else:
        path = next((p for p in _DEFAULT_WEIGHT_CANDIDATES if p.exists()),
                    _DEFAULT_WEIGHT_CANDIDATES[0])

    return YOLO(str(path))


def detect(model, bgr: np.ndarray) -> dict:
    """Run detection on a single saved BGR (IronRed palette) frame."""
    left_pt, right_pt, left_conf, right_conf = _single_stage_detect(model, bgr)
    return {
        "left_pt": left_pt,
        "right_pt": right_pt,
        "left_conf": left_conf,
        "right_conf": right_conf,
    }
