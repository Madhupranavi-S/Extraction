"""
detector_tfake_landmark.py
============================
Eval-harness wrapper for the T-FAKE 478-point thermal facial landmark
model (MediaPipe-convention indices), reading off the inner-canthus
landmarks (133 = left, 362 = right).

Source: extracted from the live "Thermal Health Monitor" script. Camera
capture, BME280 ambient sensor, fever classification, debug display, and
CSV logging are stripped.

============================================================================
READ THIS BEFORE TRUSTING THIS MODEL'S NUMBERS IN YOUR REPORT
============================================================================
This model is architecturally different from the other four in a way that
matters a lot for a fair comparison:

1. IT ALWAYS REPORTS BOTH POINTS. The landmarker returns all 478 indices
   on every frame where a face is found at all — there's no per-landmark
   "not found" signal, only a confidence score. So this detector's
   occluded_side_false_positive_rate will be close to 1.0 *by
   construction*, not because it's worse at detection — it simply has no
   mechanism to say "I don't see this side." Don't read that number as
   "this model is bad," read it as "this model can't pass the occlusion
   filter at all," which is a different (and still real) conclusion.

2. INPUT FORMAT MISMATCH — this is the important one. The other four
   detectors all consume the saved BGR IronRed-palette PNG directly, which
   is what the README says every detector gets. T-FAKE does NOT, in the
   original live script: it runs on a grayscale image built from the
   *actual decoded temperature array*, clipped to a fixed 28-38C range and
   normalized to 0-255 — a completely different mapping than "IronRed
   palette converted to grayscale." IronRed's color-to-brightness mapping
   was also auto-ranged per-frame (rescaled to that frame's own min/max),
   so even a "convert the saved PNG to grayscale" approximation won't
   recover the same image T-FAKE was actually built around.

   Properly replaying this model needs the original per-pixel temperature
   array, not the saved PNG. That means either:
     (a) capture_session.py also saved the calibration status needed to
         decode each frame's <image_id>_y16.npy into real Celsius values
         (check this — if it didn't, this can't be reconstructed after
         the fact), or
     (b) you accept the fallback below, which just grayscales the saved
         PNG and is very likely to bias this model's reported accuracy
         (probably pessimistically) relative to how it performs live.

   The detect() function below tries path (a) first if you pass a
   `temps_c` array in, and only falls back to the (b) approximation
   (with a one-time warning) if you don't. If your eval_harness.py only
   ever calls detect(model, bgr) with no way to pass temperature data
   through, you're getting the (b) approximation for every frame —
   worth fixing before you trust this row of the report.
============================================================================

Interface
---------
load_models() -> landmarker
detect(model, bgr, temps_c=None) -> {
    "left_pt":  (x, y) or None,
    "right_pt": (x, y) or None,
    "left_conf":  float,
    "right_conf": float,
}
`temps_c`, if provided, is the decoded-temperature float array for this
frame (same shape as the thermal sensor, e.g. 288x384) — pass this
whenever you have it for a fair comparison. If eval_harness.py's call
signature can't pass a third argument, see the note above.
"""

import warnings
import numpy as np
import cv2

try:
    from tfan import ThermalLandmarks
except ImportError:
    ThermalLandmarks = None

# =============================================================
# MODEL CONFIG (unchanged from source)
# =============================================================
TFAKE_SIZE = 224

# Landmark indices (MediaPipe 478-point convention)
LEFT_INNER_CANTHUS  = 133
RIGHT_INNER_CANTHUS = 362

# Fixed clip range the original live script used to build its grayscale
# input from real decoded temperatures.
CLIP_MIN_C = 28.0
CLIP_MAX_C = 38.0

_warned_fallback = False


def scale_landmarks(lms, orig_w, orig_h):
    scaled = lms.copy()
    scaled[:, 0] = lms[:, 0] * orig_w / TFAKE_SIZE
    scaled[:, 1] = lms[:, 1] * orig_h / TFAKE_SIZE
    return scaled


def _gray_from_temps(temps_c: np.ndarray) -> np.ndarray:
    """Faithful path: same clip/normalize the original live script used."""
    temps_clipped = np.clip(temps_c, CLIP_MIN_C, CLIP_MAX_C)
    gray = ((temps_clipped - CLIP_MIN_C) /
            (CLIP_MAX_C - CLIP_MIN_C) * 255).astype(np.uint8)
    return gray


def _gray_from_bgr_fallback(bgr: np.ndarray) -> np.ndarray:
    """
    APPROXIMATION ONLY — see the module docstring. This does not reproduce
    the temperature-derived grayscale the model expects; it's here so the
    harness doesn't crash on this detector, not because it's correct.
    """
    global _warned_fallback
    if not _warned_fallback:
        warnings.warn(
            "detector_tfake_landmark: no temps_c array provided — falling "
            "back to grayscale(saved BGR PNG), which does NOT match this "
            "model's actual input pipeline. Results for this model are "
            "likely skewed. See the module docstring.",
            stacklevel=2,
        )
        _warned_fallback = True
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)


def _detect(landmarker, bgr: np.ndarray, temps_c=None):
    h, w = bgr.shape[:2]

    if temps_c is not None:
        gray = _gray_from_temps(temps_c)
    else:
        gray = _gray_from_bgr_fallback(bgr)

    gray_224 = cv2.resize(gray, (TFAKE_SIZE, TFAKE_SIZE))

    try:
        landmarks, confidences = landmarker.process(gray_224)
        face_detected = (landmarks is not None and
                          isinstance(landmarks, list) and
                          len(landmarks) > 0)
    except Exception:
        face_detected = False
        landmarks = None
        confidences = None

    if not face_detected:
        return None, None, 0.0, 0.0

    lms = np.array(landmarks[0], dtype=np.float32)
    confs = np.array(
        confidences[0] if isinstance(confidences, list) else confidences,
        dtype=np.float32).flatten()

    lms_scaled = scale_landmarks(lms, w, h)

    lc_x = float(lms_scaled[LEFT_INNER_CANTHUS, 0])
    lc_y = float(lms_scaled[LEFT_INNER_CANTHUS, 1])
    rc_x = float(lms_scaled[RIGHT_INNER_CANTHUS, 0])
    rc_y = float(lms_scaled[RIGHT_INNER_CANTHUS, 1])

    lc_conf = float(confs[LEFT_INNER_CANTHUS])  if LEFT_INNER_CANTHUS  < len(confs) else 0.5
    rc_conf = float(confs[RIGHT_INNER_CANTHUS]) if RIGHT_INNER_CANTHUS < len(confs) else 0.5

    # NOTE: this model has no concept of "occluded, didn't report" — it
    # always returns a point for every landmark whenever a face is found
    # at all. left_pt/right_pt are therefore never None here (only both-
    # None together, if no face was found). This is the architectural
    # property flagged in the module docstring, not a bug in this wrapper.
    return (lc_x, lc_y), (rc_x, rc_y), lc_conf, rc_conf


# =============================================================
# PUBLIC HARNESS INTERFACE
# =============================================================
def load_models(weights_path=None):
    """weights_path is unused (kept for interface consistency) — T-FAKE
    here loads via the tfan package's own model resolution."""
    if ThermalLandmarks is None:
        raise ImportError("tfan package is required for the T-FAKE landmarker")
    return ThermalLandmarks(device="cpu", n_landmarks=478)


def detect(model, bgr: np.ndarray, temps_c: np.ndarray = None) -> dict:
    left_pt, right_pt, left_conf, right_conf = _detect(model, bgr, temps_c=temps_c)
    return {
        "left_pt": left_pt,
        "right_pt": right_pt,
        "left_conf": left_conf,
        "right_conf": right_conf,
    }
