"""
detector_twostage_adaptivezoom.py
===================================
Eval-harness wrapper for the TWO-STAGE pipeline, ADAPTIVE-ZOOM variant —
the later iteration of detector_twostage_fixedzoom.py.

Source: extracted from the updated live "Thermal Health Monitor" script.
Camera capture, BME280 ambient sensor, fever classification, debug
display, and CSV logging are stripped. Detection math is unchanged.

WHAT'S DIFFERENT FROM THE FIXED-ZOOM VERSION:
  - Zoom factor scales to the detected face's actual size (a small/far
    face gets zoomed more, a large/close face gets zoomed less) instead
    of always using a flat 2.0x, so stage 2 sees a roughly consistent
    crop size (TARGET_CROP_PX) regardless of distance.
  - Faces under MIN_FACE_DIM_PX (raw sensor pixels) are flagged "too far"
    and stage 2 is skipped entirely — at that point there typically
    aren't enough real pixels across the canthus for a reading to mean
    anything, so it doesn't guess.
  - The temperature-sampling radius (not used by this harness, but kept
    for completeness / in case you want it later) scales to the detected
    canthus box size instead of a fixed radius=3.

IMPORTANT FOR YOUR EVAL: when a frame is flagged "too_far", left_pt and
right_pt both come back None — which the harness will correctly score as
a miss on both sides (not a false detection). That's intentional and
matches how this model behaves live: it would rather say nothing than
guess at long range.

Interface
---------
load_models(weights_path=None) -> {"face_model": ..., "canthus_model": ...}
detect(models, bgr) -> {
    "left_pt":  (x, y) or None,
    "right_pt": (x, y) or None,
    "left_conf":  float,
    "right_conf": float,
    "too_far": bool,           # extra metadata
    "face_box": tuple or None, # extra metadata
}
"""

from pathlib import Path
import numpy as np
import cv2

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None

# =============================================================
# STAGE 1 — FACE DETECTOR CONFIG
# =============================================================
FACE_CONF_THRESH = 0.25
FACE_IMG_SIZE    = 320
ZOOM_PAD_FRAC    = 0.25
ZOOM_SCALE       = 2.0   # fallback only, used if ADAPTIVE_ZOOM is False

# =============================================================
# STAGE 2 — CANTHUS MODEL CONFIG
# =============================================================
CLASS_LEFT  = 0
CLASS_RIGHT = 1
CONF_THRESH = 0.25
IMG_SIZE    = 320

# =============================================================
# FAR-DISTANCE ROBUSTNESS CONFIG
# Tune these against your own hardware/test distances.
# =============================================================
ADAPTIVE_ZOOM     = True
TARGET_CROP_PX    = 240
MIN_ZOOM_SCALE    = 1.5
MAX_ZOOM_SCALE    = 8.0

MIN_FACE_DIM_PX   = 18   # raw-sensor-pixel face size below which we don't trust a reading

MIN_SAMPLE_RADIUS = 1
MAX_SAMPLE_RADIUS = 4


def _preprocess(img_bgr: np.ndarray) -> np.ndarray:
    return img_bgr


def _detect_face(face_model, bgr: np.ndarray):
    results = face_model(bgr, imgsz=FACE_IMG_SIZE, conf=FACE_CONF_THRESH,
                          verbose=False)[0]

    best_box  = None
    best_conf = 0.0

    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        confs = results.boxes.conf.cpu().numpy()
        for box, conf in zip(boxes, confs):
            if conf > best_conf:
                best_conf = float(conf)
                best_box  = (int(box[0]), int(box[1]), int(box[2]), int(box[3]))

    return best_box


def _crop_and_zoom(bgr: np.ndarray, face_box):
    """
    Pad + crop the face box, then upscale ADAPTIVELY: scale chosen so the
    padded crop's short side reaches TARGET_CROP_PX (clamped to
    [MIN_ZOOM_SCALE, MAX_ZOOM_SCALE]). Does not add real resolution — just
    standardizes crop size fed to stage 2 regardless of distance.
    Returns (zoomed_crop_bgr, crop_origin, scale).
    """
    h, w = bgr.shape[:2]
    x1, y1, x2, y2 = face_box

    box_w = x2 - x1
    box_h = y2 - y1
    pad_x = int(box_w * ZOOM_PAD_FRAC)
    pad_y = int(box_h * ZOOM_PAD_FRAC)

    cx1 = max(0, x1 - pad_x)
    cy1 = max(0, y1 - pad_y)
    cx2 = min(w, x2 + pad_x)
    cy2 = min(h, y2 + pad_y)

    crop = bgr[cy1:cy2, cx1:cx2]
    if crop.size == 0:
        return None, (cx1, cy1), 1.0

    crop_h, crop_w = crop.shape[:2]

    if ADAPTIVE_ZOOM:
        short_side = min(crop_w, crop_h)
        scale = TARGET_CROP_PX / float(short_side) if short_side > 0 else ZOOM_SCALE
        scale = max(MIN_ZOOM_SCALE, min(MAX_ZOOM_SCALE, scale))
    else:
        scale = ZOOM_SCALE

    zoomed = cv2.resize(crop, None, fx=scale, fy=scale,
                         interpolation=cv2.INTER_CUBIC)

    return zoomed, (cx1, cy1), scale


def _single_stage_detect(model, bgr: np.ndarray):
    """
    Returns (left_pt, right_pt, left_conf, right_conf, left_box, right_box)
    in the input image's own coords. left_box/right_box are (w, h) of the
    detected box, used downstream to size the sampling radius.
    """
    prepped = _preprocess(bgr)
    results = model(prepped, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]

    left_pt   = None
    right_pt  = None
    left_box  = None
    right_box = None
    left_conf  = 0.0
    right_conf = 0.0

    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        clss  = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()

        for box, cls_id, conf in zip(boxes, clss, confs):
            cx = float((box[0] + box[2]) / 2.0)
            cy = float((box[1] + box[3]) / 2.0)
            bw = float(box[2] - box[0])
            bh = float(box[3] - box[1])

            if cls_id == CLASS_LEFT and conf > left_conf:
                left_pt   = (cx, cy)
                left_box  = (bw, bh)
                left_conf = float(conf)
            elif cls_id == CLASS_RIGHT and conf > right_conf:
                right_pt   = (cx, cy)
                right_box  = (bw, bh)
                right_conf = float(conf)

    return left_pt, right_pt, left_conf, right_conf, left_box, right_box


def _two_stage_detect(face_model, canthus_model, bgr: np.ndarray):
    """
    Returns (left_pt, right_pt, left_conf, right_conf, face_box,
              left_size_px, right_size_px, too_far) — all in full-frame
    coords except left_size_px/right_size_px which are the canthus box
    size translated back to raw full-frame pixels.
    """
    face_box = _detect_face(face_model, bgr)
    if face_box is None:
        return None, None, 0.0, 0.0, None, None, None, False

    x1, y1, x2, y2 = face_box
    too_far = min(x2 - x1, y2 - y1) < MIN_FACE_DIM_PX
    if too_far:
        return None, None, 0.0, 0.0, face_box, None, None, True

    zoomed, (ox, oy), scale = _crop_and_zoom(bgr, face_box)
    if zoomed is None:
        return None, None, 0.0, 0.0, face_box, None, None, False

    left_pt, right_pt, left_conf, right_conf, left_box, right_box = \
        _single_stage_detect(canthus_model, zoomed)

    if left_pt is not None:
        lx, ly = left_pt
        left_pt = (lx / scale + ox, ly / scale + oy)
    if right_pt is not None:
        rx, ry = right_pt
        right_pt = (rx / scale + ox, ry / scale + oy)

    left_size_px  = (left_box[0]  / scale, left_box[1]  / scale) if left_box  else None
    right_size_px = (right_box[0] / scale, right_box[1] / scale) if right_box else None

    return left_pt, right_pt, left_conf, right_conf, face_box, left_size_px, right_size_px, False


# =============================================================
# PUBLIC HARNESS INTERFACE
# =============================================================
_DEFAULT_FACE_CANDIDATES = [
    Path("thermal-canthus-detector_new") / "thermal_detector.pt",
    Path("thermal_detector_new.pt"),
    Path.home() / "thermal-canthus-detector_new" / "thermal_detector.pt",
]
_DEFAULT_CANTHUS_CANDIDATES = [
    Path("thermal-canthus-detector") / "detect.pt",
    Path("detect.pt"),
    Path.home() / "thermal-canthus-detector" / "detect.pt",
]


def load_models(weights_path=None):
    """
    weights_path: None to auto-detect both weight files, OR a dict
    {"face": "...", "canthus": "..."} to specify both explicitly.
    """
    if YOLO is None:
        raise ImportError("ultralytics is required: pip install ultralytics")

    if isinstance(weights_path, dict):
        face_path = Path(weights_path["face"])
        canthus_path = Path(weights_path["canthus"])
    else:
        face_path = next((p for p in _DEFAULT_FACE_CANDIDATES if p.exists()),
                          _DEFAULT_FACE_CANDIDATES[0])
        canthus_path = next((p for p in _DEFAULT_CANTHUS_CANDIDATES if p.exists()),
                             _DEFAULT_CANTHUS_CANDIDATES[0])

    return {
        "face_model": YOLO(str(face_path)),
        "canthus_model": YOLO(str(canthus_path)),
    }


def detect(models, bgr: np.ndarray) -> dict:
    left_pt, right_pt, left_conf, right_conf, face_box, \
        left_size_px, right_size_px, too_far = _two_stage_detect(
            models["face_model"], models["canthus_model"], bgr)
    return {
        "left_pt": left_pt,
        "right_pt": right_pt,
        "left_conf": left_conf,
        "right_conf": right_conf,
        "too_far": too_far,
        "face_box": face_box,
    }
