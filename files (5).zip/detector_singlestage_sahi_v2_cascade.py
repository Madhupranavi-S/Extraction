"""
detector_singlestage_sahi_v2_cascade.py
========================================
Eval-harness wrapper for the SINGLE-STAGE canthus model, MULTI-SCALE
CASCADE SAHI variant — the later iteration of detector_singlestage_sahi_v1.py.

Source: extracted from the updated live "Thermal Health Monitor" script.
Camera capture, BME280 ambient sensor, fever classification, debug display,
and CSV logging are stripped (irrelevant to point localization). The
detection math is unchanged.

WHY THIS DIFFERS FROM v1: tracing the actual training pipeline showed the
model was trained on 300x300px FACE-FILLING crops (SAHI over 464x464
face-filling images, no upscale at train time). v1's fixed 96x72px tiles
were far smaller and far less face-like than anything the model saw in
training — explaining its "sometimes detects, sometimes doesn't" behavior.
This version slices at face-scale instead, with three distance tiers
(NEAR ~1-1.5m / FAR ~1.5-2m / FAR2 >2m) run as a CASCADE: cheapest tier
first, only escalating to the next tier if a side is still missing, to
keep typical-case compute down on low-power hardware.

Interface
---------
load_models(weights_path=None) -> model
detect(model, bgr) -> {
    "left_pt":  (x, y) or None,
    "right_pt": (x, y) or None,
    "left_conf":  float,
    "right_conf": float,
}
"""

from pathlib import Path
import numpy as np
import cv2

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None

# =============================================================
# MODEL CONFIG (unchanged from source)
# =============================================================
CLASS_LEFT  = 0
CLASS_RIGHT = 1
CONF_THRESH = 0.25
IMG_SIZE    = 320

TRAIN_CROP_PX = 300  # actual training slice size

NEAR_SLICE_H = 220
NEAR_SLICE_W = 220
NEAR_UPSCALE = TRAIN_CROP_PX / NEAR_SLICE_W

FAR_SLICE_H = 140
FAR_SLICE_W = 140
FAR_UPSCALE = TRAIN_CROP_PX / FAR_SLICE_W

FAR2_SLICE_H = 90
FAR2_SLICE_W = 90
FAR2_UPSCALE = TRAIN_CROP_PX / FAR2_SLICE_W

SAHI_OVERLAP   = 0.35
SAHI_MERGE_IOU = 0.3

# Off by default for batch-eval runs — see v1 for rationale.
VERBOSE = False


def _preprocess(img_bgr: np.ndarray) -> np.ndarray:
    return img_bgr


def _make_slices(width: int, height: int, slice_w: int, slice_h: int, overlap: float):
    stride_x = max(1, int(slice_w * (1 - overlap)))
    stride_y = max(1, int(slice_h * (1 - overlap)))

    xs = list(range(0, max(width - slice_w, 0) + 1, stride_x))
    ys = list(range(0, max(height - slice_h, 0) + 1, stride_y))
    if not xs or xs[-1] != max(width - slice_w, 0):
        xs.append(max(width - slice_w, 0))
    if not ys or ys[-1] != max(height - slice_h, 0):
        ys.append(max(height - slice_h, 0))

    slices = []
    for y1 in ys:
        y2 = min(y1 + slice_h, height)
        y1 = max(0, y2 - slice_h)
        for x1 in xs:
            x2 = min(x1 + slice_w, width)
            x1 = max(0, x2 - slice_w)
            slices.append((x1, y1, x2, y2))
    return slices


def _iou(box_a, box_b) -> float:
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)

    inter_w = max(0.0, inter_x2 - inter_x1)
    inter_h = max(0.0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h
    if inter_area <= 0:
        return 0.0

    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter_area
    if union <= 0:
        return 0.0
    return inter_area / union


def _nms_merge(dets):
    if not dets:
        return []
    dets = sorted(dets, key=lambda d: d[1], reverse=True)
    kept = []
    used = [False] * len(dets)

    for i, (box_i, conf_i) in enumerate(dets):
        if used[i]:
            continue
        kept.append((box_i, conf_i))
        for j in range(i + 1, len(dets)):
            if used[j]:
                continue
            box_j, _ = dets[j]
            if _iou(box_i, box_j) > SAHI_MERGE_IOU:
                used[j] = True
    return kept


def _run_pass(model, prepped, slice_w, slice_h, upscale, overlap):
    """One SAHI pass at one scale tier. Returns (left_dets, right_dets), pre-NMS."""
    h, w = prepped.shape[:2]
    left_dets  = []
    right_dets = []

    for (x1, y1, x2, y2) in _make_slices(w, h, slice_w, slice_h, overlap):
        patch = prepped[y1:y2, x1:x2]
        if patch.size == 0:
            continue

        if upscale != 1.0:
            patch_in = cv2.resize(
                patch, None, fx=upscale, fy=upscale,
                interpolation=cv2.INTER_CUBIC)
        else:
            patch_in = patch

        results = model(patch_in, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]

        if VERBOSE and results.boxes is not None and len(results.boxes) > 0:
            print(f"  slice[{slice_w}x{slice_h}@{upscale}x] ({x1},{y1})-({x2},{y2}): "
                  f"max_conf={results.boxes.conf.max():.3f}, "
                  f"cls={results.boxes.cls.cpu().numpy().astype(int).tolist()}")

        if results.boxes is None or len(results.boxes) == 0:
            continue

        boxes = results.boxes.xyxy.cpu().numpy()
        clss  = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()

        for box, cls_id, conf in zip(boxes, clss, confs):
            full_box = (
                float(box[0] / upscale + x1),
                float(box[1] / upscale + y1),
                float(box[2] / upscale + x1),
                float(box[3] / upscale + y1),
            )
            if cls_id == CLASS_LEFT:
                left_dets.append((full_box, float(conf)))
            elif cls_id == CLASS_RIGHT:
                right_dets.append((full_box, float(conf)))

    return left_dets, right_dets


def _single_stage_detect(model, bgr: np.ndarray):
    """
    Cascading multi-scale SAHI: try NEAR first (cheapest), only escalate
    to FAR / FAR2 if a side is still missing. Returns (left_pt, right_pt,
    left_conf, right_conf) in full-frame coords; either point may be None.
    """
    prepped = _preprocess(bgr)

    tiers = [
        (NEAR_SLICE_W, NEAR_SLICE_H, NEAR_UPSCALE),
        (FAR_SLICE_W,  FAR_SLICE_H,  FAR_UPSCALE),
        (FAR2_SLICE_W, FAR2_SLICE_H, FAR2_UPSCALE),
    ]

    all_left_dets  = []
    all_right_dets = []

    for slice_w, slice_h, upscale in tiers:
        left_dets, right_dets = _run_pass(
            model, prepped, slice_w, slice_h, upscale, SAHI_OVERLAP)
        all_left_dets  += left_dets
        all_right_dets += right_dets

        have_left  = any(conf >= CONF_THRESH for _, conf in all_left_dets)
        have_right = any(conf >= CONF_THRESH for _, conf in all_right_dets)
        if have_left and have_right:
            break

    left_dets  = _nms_merge(all_left_dets)
    right_dets = _nms_merge(all_right_dets)

    left_pt  = None
    right_pt = None
    left_conf  = 0.0
    right_conf = 0.0

    if left_dets:
        (lx1, ly1, lx2, ly2), left_conf = max(left_dets, key=lambda d: d[1])
        left_pt = (float((lx1 + lx2) / 2.0), float((ly1 + ly2) / 2.0))

    if right_dets:
        (rx1, ry1, rx2, ry2), right_conf = max(right_dets, key=lambda d: d[1])
        right_pt = (float((rx1 + rx2) / 2.0), float((ry1 + ry2) / 2.0))

    return left_pt, right_pt, left_conf, right_conf


# =============================================================
# PUBLIC HARNESS INTERFACE
# =============================================================
_DEFAULT_WEIGHT_CANDIDATES = [
    Path("thermal-canthus-detector") / "detect.pt",
    Path("detect.pt"),
    Path.home() / "thermal-canthus-detector" / "detect.pt",
]


def load_models(weights_path=None):
    if YOLO is None:
        raise ImportError("ultralytics is required: pip install ultralytics")

    if weights_path:
        path = Path(weights_path)
    else:
        path = next((p for p in _DEFAULT_WEIGHT_CANDIDATES if p.exists()),
                    _DEFAULT_WEIGHT_CANDIDATES[0])

    return YOLO(str(path))


def detect(model, bgr: np.ndarray) -> dict:
    left_pt, right_pt, left_conf, right_conf = _single_stage_detect(model, bgr)
    return {
        "left_pt": left_pt,
        "right_pt": right_pt,
        "left_conf": left_conf,
        "right_conf": right_conf,
    }
