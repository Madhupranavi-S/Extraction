"""
detector_twostage_fixedzoom.py
================================
Eval-harness wrapper for the TWO-STAGE pipeline: stage 1 detects a face
box on the full frame, stage 2 crops + zooms into that box by a FIXED
2.0x factor and runs the canthus model on the zoomed crop.

Source: extracted from the live "Thermal Health Monitor" script. Camera
capture, BME280 ambient sensor, fever classification, debug display, and
CSV logging are stripped. Detection math is unchanged.

This is the EARLIER two-stage variant — fixed zoom regardless of how
close/far the detected face actually is. See
detector_twostage_adaptivezoom.py for the later iteration that scales
zoom (and the temperature-sampling radius) to the detected face size
instead, plus a "too far to trust" gate. Keep both: that's the comparison
the harness is for.

Interface
---------
load_models(weights_path=None) -> {"face_model": ..., "canthus_model": ...}
detect(models, bgr) -> {
    "left_pt":  (x, y) or None,
    "right_pt": (x, y) or None,
    "left_conf":  float,
    "right_conf": float,
}
"""

from pathlib import Path
import numpy as np
import cv2

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None

# =============================================================
# STAGE 1 — FACE DETECTOR CONFIG
# =============================================================
FACE_CONF_THRESH = 0.25
FACE_IMG_SIZE    = 320
ZOOM_PAD_FRAC    = 0.25
ZOOM_SCALE       = 2.0   # fixed upscale of the padded crop before stage 2

# =============================================================
# STAGE 2 — CANTHUS MODEL CONFIG
# =============================================================
CLASS_LEFT  = 0
CLASS_RIGHT = 1
CONF_THRESH = 0.25
IMG_SIZE    = 320


def _preprocess(img_bgr: np.ndarray) -> np.ndarray:
    return img_bgr


def _detect_face(face_model, bgr: np.ndarray):
    """Highest-confidence face box (x1, y1, x2, y2) in full-frame coords, or None."""
    results = face_model(bgr, imgsz=FACE_IMG_SIZE, conf=FACE_CONF_THRESH,
                          verbose=False)[0]

    best_box  = None
    best_conf = 0.0

    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        confs = results.boxes.conf.cpu().numpy()
        for box, conf in zip(boxes, confs):
            if conf > best_conf:
                best_conf = float(conf)
                best_box  = (int(box[0]), int(box[1]), int(box[2]), int(box[3]))

    return best_box


def _crop_and_zoom(bgr: np.ndarray, face_box):
    """
    Pad + crop the face box, upscale by the fixed ZOOM_SCALE.
    Returns (zoomed_crop_bgr, crop_origin, scale).
    """
    h, w = bgr.shape[:2]
    x1, y1, x2, y2 = face_box

    box_w = x2 - x1
    box_h = y2 - y1
    pad_x = int(box_w * ZOOM_PAD_FRAC)
    pad_y = int(box_h * ZOOM_PAD_FRAC)

    cx1 = max(0, x1 - pad_x)
    cy1 = max(0, y1 - pad_y)
    cx2 = min(w, x2 + pad_x)
    cy2 = min(h, y2 + pad_y)

    crop = bgr[cy1:cy2, cx1:cx2]
    if crop.size == 0:
        return None, (cx1, cy1), 1.0

    zoomed = cv2.resize(crop, None, fx=ZOOM_SCALE, fy=ZOOM_SCALE,
                         interpolation=cv2.INTER_LINEAR)

    return zoomed, (cx1, cy1), ZOOM_SCALE


def _single_stage_detect(model, bgr: np.ndarray):
    """Run the canthus model on whatever image is passed in (here: the zoomed crop)."""
    prepped = _preprocess(bgr)
    results = model(prepped, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]

    left_pt  = None
    right_pt = None
    left_conf  = 0.0
    right_conf = 0.0

    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        clss  = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()

        for box, cls_id, conf in zip(boxes, clss, confs):
            cx = float((box[0] + box[2]) / 2.0)
            cy = float((box[1] + box[3]) / 2.0)

            if cls_id == CLASS_LEFT and conf > left_conf:
                left_pt   = (cx, cy)
                left_conf = float(conf)
            elif cls_id == CLASS_RIGHT and conf > right_conf:
                right_pt   = (cx, cy)
                right_conf = float(conf)

    return left_pt, right_pt, left_conf, right_conf


def _two_stage_detect(face_model, canthus_model, bgr: np.ndarray):
    """
    Stage 1: detect face. Stage 2: crop+zoom (fixed 2x) + detect canthi.
    Returns (left_pt, right_pt, left_conf, right_conf, face_box), all in
    full-frame coords. face_box is None if stage 1 found nothing.
    """
    face_box = _detect_face(face_model, bgr)
    if face_box is None:
        return None, None, 0.0, 0.0, None

    zoomed, (ox, oy), scale = _crop_and_zoom(bgr, face_box)
    if zoomed is None:
        return None, None, 0.0, 0.0, face_box

    left_pt, right_pt, left_conf, right_conf = _single_stage_detect(
        canthus_model, zoomed)

    if left_pt is not None:
        lx, ly = left_pt
        left_pt = (lx / scale + ox, ly / scale + oy)
    if right_pt is not None:
        rx, ry = right_pt
        right_pt = (rx / scale + ox, ry / scale + oy)

    return left_pt, right_pt, left_conf, right_conf, face_box


# =============================================================
# PUBLIC HARNESS INTERFACE
# =============================================================
_DEFAULT_FACE_CANDIDATES = [
    Path("thermal-canthus-detector_new") / "thermal_detector.pt",
    Path("thermal_detector_new.pt"),
    Path.home() / "thermal-canthus-detector_new" / "thermal_detector.pt",
]
_DEFAULT_CANTHUS_CANDIDATES = [
    Path("thermal-canthus-detector") / "detect.pt",
    Path("detect.pt"),
    Path.home() / "thermal-canthus-detector" / "detect.pt",
]


def load_models(weights_path=None):
    """
    weights_path: None to auto-detect both weight files, OR a dict
    {"face": "...", "canthus": "..."} to specify both explicitly.
    """
    if YOLO is None:
        raise ImportError("ultralytics is required: pip install ultralytics")

    if isinstance(weights_path, dict):
        face_path = Path(weights_path["face"])
        canthus_path = Path(weights_path["canthus"])
    else:
        face_path = next((p for p in _DEFAULT_FACE_CANDIDATES if p.exists()),
                          _DEFAULT_FACE_CANDIDATES[0])
        canthus_path = next((p for p in _DEFAULT_CANTHUS_CANDIDATES if p.exists()),
                             _DEFAULT_CANTHUS_CANDIDATES[0])

    return {
        "face_model": YOLO(str(face_path)),
        "canthus_model": YOLO(str(canthus_path)),
    }


def detect(models, bgr: np.ndarray) -> dict:
    left_pt, right_pt, left_conf, right_conf, face_box = _two_stage_detect(
        models["face_model"], models["canthus_model"], bgr)
    return {
        "left_pt": left_pt,
        "right_pt": right_pt,
        "left_conf": left_conf,
        "right_conf": right_conf,
        "face_box": face_box,  # extra metadata, harmless if eval_harness.py ignores it
    }
