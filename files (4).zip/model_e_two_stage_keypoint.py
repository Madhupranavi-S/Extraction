"""
model_e_two_stage_keypoint.py
Stage 1: face detector. Stage 2: canthus localization via an external repo's
load_models()/detect() — same weights filename pattern (thermal_canthus_yolo.pt)
as Model D, so this is *likely* the same keypoint architecture wrapped in a
face-crop step instead of SAHI tiling. This wrapper cannot fully audit what
detect() does internally (it's a black box from the repo) — note `notes`
field in the result for that caveat. Confirm by inspecting
thermal-canthus-detector_new/detect_canthus.py directly if certainty matters.
"""
import sys
from pathlib import Path
import numpy as np
from .common import DetectionResult

_models = None


def load(detector_weights_path, canthus_weights_path, repo_dir):
    """repo_dir: directory containing detect_canthus.py (load_models, detect)."""
    global _models
    sys.path.insert(0, str(repo_dir))
    from detect_canthus import load_models  # noqa
    _models = load_models(detector_weights_path, canthus_weights_path)


def detect(bgr: np.ndarray, min_face_px: int = 20) -> DetectionResult:
    if _models is None:
        raise RuntimeError("Call load(detector_weights, canthus_weights, repo_dir) before detect().")

    sys.path.insert(0, str(Path(__file__).resolve()))  # no-op safeguard if already inserted
    from detect_canthus import detect as yolo_detect  # noqa

    result = yolo_detect(_models, bgr, min_face_px=min_face_px)

    if result.face_box is None:
        return DetectionResult(None, None, None, None, notes="stage-1 face detector found nothing")
    if result.too_far:
        return DetectionResult(None, None, None, None, notes="stage-1 flagged face as too_far")

    # The external API exposes no independent per-side confidence to us.
    return DetectionResult(
        result.left, result.right, None, None,
        notes="external library call (detect_canthus.detect) — internal occlusion "
              "handling, if any, is not auditable from this wrapper"
    )
