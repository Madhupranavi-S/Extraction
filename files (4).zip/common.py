"""
common.py — shared result type for all detector wrappers.

Every model_X.py module exposes a `detect(bgr)` function with this signature:

    def detect(bgr: np.ndarray) -> DetectionResult

so the harness can call all six pipelines identically.
"""
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class DetectionResult:
    left: Optional[Tuple[float, float]]    # (x, y) in input-image pixel coords, or None
    right: Optional[Tuple[float, float]]
    left_conf: Optional[float]   # None if the model architecture has no per-side confidence
    right_conf: Optional[float]
    notes: str = ""               # e.g. "no per-keypoint confidence available"
