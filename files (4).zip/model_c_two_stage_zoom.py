"""
model_c_two_stage_zoom.py
Stage 1: face detector (thermal_detector.pt) on the full frame.
Stage 2: pad/crop/zoom into the face box, run the unchanged detect.pt
(same independent left/right classes as A/B) on the zoomed crop.
Failure mode unique to this pipeline: if stage 1 misses, stage 2 never runs.
"""
import cv2
import numpy as np
from ultralytics import YOLO
from .common import DetectionResult

FACE_CONF_THRESH = 0.25
FACE_IMG_SIZE = 320
ZOOM_PAD_FRAC = 0.25
ZOOM_SCALE = 2.0

CLASS_LEFT, CLASS_RIGHT = 0, 1
CONF_THRESH = 0.25
IMG_SIZE = 320

_face_model = None
_canthus_model = None


def load(face_weights_path: str, canthus_weights_path: str):
    global _face_model, _canthus_model
    _face_model = YOLO(str(face_weights_path))
    _canthus_model = YOLO(str(canthus_weights_path))


def _detect_face(bgr):
    results = _face_model(bgr, imgsz=FACE_IMG_SIZE, conf=FACE_CONF_THRESH, verbose=False)[0]
    best_box, best_conf = None, 0.0
    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        confs = results.boxes.conf.cpu().numpy()
        for box, conf in zip(boxes, confs):
            if conf > best_conf:
                best_conf = float(conf)
                best_box = (int(box[0]), int(box[1]), int(box[2]), int(box[3]))
    return best_box


def _crop_and_zoom(bgr, face_box):
    h, w = bgr.shape[:2]
    x1, y1, x2, y2 = face_box
    pad_x = int((x2 - x1) * ZOOM_PAD_FRAC)
    pad_y = int((y2 - y1) * ZOOM_PAD_FRAC)
    cx1, cy1 = max(0, x1 - pad_x), max(0, y1 - pad_y)
    cx2, cy2 = min(w, x2 + pad_x), min(h, y2 + pad_y)
    crop = bgr[cy1:cy2, cx1:cx2]
    if crop.size == 0:
        return None, (cx1, cy1), 1.0
    zoomed = cv2.resize(crop, None, fx=ZOOM_SCALE, fy=ZOOM_SCALE, interpolation=cv2.INTER_LINEAR)
    return zoomed, (cx1, cy1), ZOOM_SCALE


def _canthus_on_crop(bgr_crop):
    results = _canthus_model(bgr_crop, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]
    left_pt = right_pt = None
    left_conf = right_conf = 0.0
    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        clss = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()
        for box, cls_id, conf in zip(boxes, clss, confs):
            cx = float((box[0] + box[2]) / 2.0)
            cy = float((box[1] + box[3]) / 2.0)
            if cls_id == CLASS_LEFT and conf > left_conf:
                left_pt, left_conf = (cx, cy), float(conf)
            elif cls_id == CLASS_RIGHT and conf > right_conf:
                right_pt, right_conf = (cx, cy), float(conf)
    return left_pt, right_pt, left_conf, right_conf


def detect(bgr: np.ndarray) -> DetectionResult:
    if _face_model is None or _canthus_model is None:
        raise RuntimeError("Call load(face_weights, canthus_weights) before detect().")

    face_box = _detect_face(bgr)
    if face_box is None:
        return DetectionResult(None, None, 0.0, 0.0, notes="stage-1 face detector found nothing")

    zoomed, (ox, oy), scale = _crop_and_zoom(bgr, face_box)
    if zoomed is None:
        return DetectionResult(None, None, 0.0, 0.0, notes="empty crop after padding")

    left_pt, right_pt, left_conf, right_conf = _canthus_on_crop(zoomed)
    if left_pt is not None:
        left_pt = (left_pt[0] / scale + ox, left_pt[1] / scale + oy)
    if right_pt is not None:
        right_pt = (right_pt[0] / scale + ox, right_pt[1] / scale + oy)

    return DetectionResult(left_pt, right_pt, left_conf, right_conf)
