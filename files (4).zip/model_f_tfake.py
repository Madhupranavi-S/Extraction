"""
model_f_tfake.py
T-FAKE 478-point dense face mesh (MediaPipe topology). Always emits all 478
points including the canthus indices, regardless of occlusion — this is
expected to fail the occlusion-correctness metric by design (the model
regresses a canonical face shape, not "what's actually visible").
Per-point confidence exists but is informative-only here; we surface it so
the harness can test whether a confidence threshold helps at all (it likely
won't fully solve occlusion, but worth measuring rather than assuming).
"""
import numpy as np
import cv2
from tfan import ThermalLandmarks
from .common import DetectionResult

TFAKE_SIZE = 224
LEFT_INNER_CANTHUS = 133
RIGHT_INNER_CANTHUS = 362

_landmarker = None


def load():
    global _landmarker
    _landmarker = ThermalLandmarks(device="cpu", n_landmarks=478)


def _to_gray224(bgr):
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    return cv2.resize(gray, (TFAKE_SIZE, TFAKE_SIZE))


def detect(bgr: np.ndarray) -> DetectionResult:
    if _landmarker is None:
        raise RuntimeError("Call load() before detect().")

    h, w = bgr.shape[:2]
    gray_224 = _to_gray224(bgr)

    landmarks, confidences = _landmarker.process(gray_224)
    if not landmarks:
        return DetectionResult(None, None, None, None, notes="no face/landmarks returned")

    lms = np.array(landmarks[0], dtype=np.float32)
    confs = np.array(confidences[0] if isinstance(confidences, list) else confidences,
                      dtype=np.float32).flatten()

    lms_scaled = lms.copy()
    lms_scaled[:, 0] = lms[:, 0] * w / TFAKE_SIZE
    lms_scaled[:, 1] = lms[:, 1] * h / TFAKE_SIZE

    lx, ly = float(lms_scaled[LEFT_INNER_CANTHUS, 0]), float(lms_scaled[LEFT_INNER_CANTHUS, 1])
    rx, ry = float(lms_scaled[RIGHT_INNER_CANTHUS, 0]), float(lms_scaled[RIGHT_INNER_CANTHUS, 1])

    left_conf = float(confs[LEFT_INNER_CANTHUS]) if LEFT_INNER_CANTHUS < len(confs) else None
    right_conf = float(confs[RIGHT_INNER_CANTHUS]) if RIGHT_INNER_CANTHUS < len(confs) else None

    return DetectionResult(
        (lx, ly), (rx, ry), left_conf, right_conf,
        notes="dense mesh model: always emits both points; confidence is "
              "informative only, not a learned visibility/occlusion signal"
    )
