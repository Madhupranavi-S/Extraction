"""
model_b_sahi.py
Same detect.pt weights as Model A, but with SAHI-style overlapping-tile
inference to recover effective resolution at distance. Independent left/right
classes -> occlusion-correct by architecture, same as A.
"""
import cv2
import numpy as np
from ultralytics import YOLO
from .common import DetectionResult

CLASS_LEFT, CLASS_RIGHT = 0, 1
CONF_THRESH = 0.25
IMG_SIZE = 320

SAHI_SLICE_H, SAHI_SLICE_W = 72, 96
SAHI_OVERLAP = 0.35
SAHI_MERGE_IOU = 0.3
SAHI_UPSCALE = 2.0

_model = None


def load(weights_path: str):
    global _model
    _model = YOLO(str(weights_path))


def _make_slices(width, height):
    stride_x = max(1, int(SAHI_SLICE_W * (1 - SAHI_OVERLAP)))
    stride_y = max(1, int(SAHI_SLICE_H * (1 - SAHI_OVERLAP)))
    xs = list(range(0, max(width - SAHI_SLICE_W, 0) + 1, stride_x))
    ys = list(range(0, max(height - SAHI_SLICE_H, 0) + 1, stride_y))
    if not xs or xs[-1] != max(width - SAHI_SLICE_W, 0):
        xs.append(max(width - SAHI_SLICE_W, 0))
    if not ys or ys[-1] != max(height - SAHI_SLICE_H, 0):
        ys.append(max(height - SAHI_SLICE_H, 0))
    slices = []
    for y1 in ys:
        y2 = min(y1 + SAHI_SLICE_H, height)
        y1 = max(0, y2 - SAHI_SLICE_H)
        for x1 in xs:
            x2 = min(x1 + SAHI_SLICE_W, width)
            x1 = max(0, x2 - SAHI_SLICE_W)
            slices.append((x1, y1, x2, y2))
    return slices


def _iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def _nms_merge(dets):
    if not dets:
        return []
    dets = sorted(dets, key=lambda d: d[1], reverse=True)
    kept, used = [], [False] * len(dets)
    for i, (box_i, conf_i) in enumerate(dets):
        if used[i]:
            continue
        kept.append((box_i, conf_i))
        for j in range(i + 1, len(dets)):
            if not used[j] and _iou(box_i, dets[j][0]) > SAHI_MERGE_IOU:
                used[j] = True
    return kept


def detect(bgr: np.ndarray) -> DetectionResult:
    if _model is None:
        raise RuntimeError("Call load(weights_path) before detect().")

    h, w = bgr.shape[:2]
    left_dets, right_dets = [], []

    for (x1, y1, x2, y2) in _make_slices(w, h):
        patch = bgr[y1:y2, x1:x2]
        if patch.size == 0:
            continue
        patch_in = cv2.resize(patch, None, fx=SAHI_UPSCALE, fy=SAHI_UPSCALE,
                               interpolation=cv2.INTER_CUBIC) if SAHI_UPSCALE != 1.0 else patch
        results = _model(patch_in, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]
        if results.boxes is None or len(results.boxes) == 0:
            continue
        boxes = results.boxes.xyxy.cpu().numpy()
        clss = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()
        for box, cls_id, conf in zip(boxes, clss, confs):
            full_box = (
                float(box[0] / SAHI_UPSCALE + x1), float(box[1] / SAHI_UPSCALE + y1),
                float(box[2] / SAHI_UPSCALE + x1), float(box[3] / SAHI_UPSCALE + y1),
            )
            if cls_id == CLASS_LEFT:
                left_dets.append((full_box, float(conf)))
            elif cls_id == CLASS_RIGHT:
                right_dets.append((full_box, float(conf)))

    left_dets = _nms_merge(left_dets)
    right_dets = _nms_merge(right_dets)

    left_pt = right_pt = None
    left_conf = right_conf = 0.0
    if left_dets:
        (lx1, ly1, lx2, ly2), left_conf = max(left_dets, key=lambda d: d[1])
        left_pt = (float((lx1 + lx2) / 2.0), float((ly1 + ly2) / 2.0))
    if right_dets:
        (rx1, ry1, rx2, ry2), right_conf = max(right_dets, key=lambda d: d[1])
        right_pt = (float((rx1 + rx2) / 2.0), float((ry1 + ry2) / 2.0))

    return DetectionResult(left_pt, right_pt, left_conf, right_conf)
