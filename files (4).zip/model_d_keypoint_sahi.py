"""
model_d_keypoint_sahi.py
Pose/keypoint-style model (thermal_canthus_yolo.pt): one box, fixed 2-point
keypoint vector, single box-level confidence shared by both points. No
independent per-side confidence -> expected to be occlusion-INCORRECT
(reports both points regardless of visibility) regardless of distance fix.
"""
import sys
from pathlib import Path
import numpy as np
import cv2
from .common import DetectionResult

SAHI_SLICE_H, SAHI_SLICE_W = 144, 192
SAHI_OVERLAP = 0.1

_model = None


def load(weights_path, repo_dir=None):
    """
    repo_dir: directory containing detect_canthus.py (load_model). If your
    thermal_canthus_yolo.pt is loaded via ultralytics.YOLO directly, you can
    skip repo_dir and we fall back to that.
    """
    global _model
    if repo_dir is not None:
        sys.path.insert(0, str(repo_dir))
        from detect_canthus import load_model  # noqa
        _model = load_model(weights_path)
    else:
        from ultralytics import YOLO
        _model = YOLO(str(weights_path))


def _clahe(img_bgr):
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    return cv2.cvtColor(clahe.apply(gray), cv2.COLOR_GRAY2RGB)


def detect(bgr: np.ndarray) -> DetectionResult:
    if _model is None:
        raise RuntimeError("Call load(weights_path, repo_dir) before detect().")

    orig_h, orig_w = bgr.shape[:2]
    stride_y = int(SAHI_SLICE_H * (1 - SAHI_OVERLAP))
    stride_x = int(SAHI_SLICE_W * (1 - SAHI_OVERLAP))

    best_conf = -1.0
    best_left = best_right = None

    y = 0
    while y < orig_h:
        y2 = min(y + SAHI_SLICE_H, orig_h)
        y1 = max(0, y2 - SAHI_SLICE_H)
        x = 0
        while x < orig_w:
            x2 = min(x + SAHI_SLICE_W, orig_w)
            x1 = max(0, x2 - SAHI_SLICE_W)
            patch = bgr[y1:y2, x1:x2]
            patch_prep = _clahe(patch)
            results = _model(patch_prep, verbose=False)[0]
            if results.keypoints is not None and len(results.keypoints) > 0:
                idx = int(results.boxes.conf.cpu().numpy().argmax())
                conf = float(results.boxes.conf.cpu().numpy()[idx])
                if conf > best_conf:
                    kpts = results.keypoints.xy[idx].cpu().numpy()
                    if kpts.shape[0] >= 2:
                        lx, ly = int(kpts[0, 0]) + x1, int(kpts[0, 1]) + y1
                        rx, ry = int(kpts[1, 0]) + x1, int(kpts[1, 1]) + y1
                        best_left = (lx, ly) if (kpts[0, 0] > 0 or kpts[0, 1] > 0) else None
                        best_right = (rx, ry) if (kpts[1, 0] > 0 or kpts[1, 1] > 0) else None
                        best_conf = conf
            x += stride_x
            if x2 == orig_w:
                break
        y += stride_y
        if y2 == orig_h:
            break

    conf_val = max(best_conf, 0.0)
    # NOTE: this architecture has a single shared confidence for the whole
    # keypoint pair, not independent per-side confidence. We surface it
    # identically on both sides and flag that in `notes` so the harness/
    # report doesn't mistake this for true per-side confidence.
    return DetectionResult(
        best_left, best_right, conf_val, conf_val,
        notes="single shared box-confidence, not independent per-side confidence"
    )
