"""
eval_harness.py
================
Runs all six detector wrappers against a labeled frame set and reports, per
model x distance-bucket x occlusion-condition:
  - detection precision / recall / F1 per side (this is what exposes the
    occlusion-correctness gap between A/B/C vs D/E/F)
  - pixel localization error (when a side is correctly detected as present)
  - mean per-frame latency

Expected ground-truth CSV columns (matches annotate_tool.html export):
  image_id, image_path, subject_id, distance_m, occlusion,
  gt_left_x, gt_left_y, gt_left_visible,
  gt_right_x, gt_right_y, gt_right_visible

Edit the CONFIG section below to point at your weights, then run:
    python eval_harness.py --gt ./captures/annotations.csv --images-dir ./captures --out report.csv
"""
import argparse
import csv
import math
import time
from pathlib import Path
from collections import defaultdict

import cv2
import numpy as np

from detectors import MODEL_REGISTRY

# =============================================================
# CONFIG — fill in paths before running. Models you haven't set
# up yet can be commented out of ACTIVE_MODELS.
# =============================================================
ACTIVE_MODELS = list(MODEL_REGISTRY.keys())  # edit to subset while iterating

MATCH_PIXEL_THRESHOLD = 8.0  # a detected point within this many px of GT counts as correct


def setup_models():
    """
    Calls each model's load(...) once. EDIT THESE PATHS for your environment.
    """
    reg = MODEL_REGISTRY

    if "A_single_stage_no_sahi" in ACTIVE_MODELS:
        reg["A_single_stage_no_sahi"].load(weights_path="weights/detect.pt")

    if "B_single_stage_sahi" in ACTIVE_MODELS:
        reg["B_single_stage_sahi"].load(weights_path="weights/detect.pt")

    if "C_two_stage_zoom" in ACTIVE_MODELS:
        reg["C_two_stage_zoom"].load(
            face_weights_path="weights/thermal_detector.pt",
            canthus_weights_path="weights/detect.pt",
        )

    if "D_keypoint_sahi" in ACTIVE_MODELS:
        reg["D_keypoint_sahi"].load(
            weights_path="weights/thermal_canthus_yolo.pt",
            repo_dir=None,  # set to repo path if it must load via detect_canthus.load_model
        )

    if "E_two_stage_keypoint" in ACTIVE_MODELS:
        reg["E_two_stage_keypoint"].load(
            detector_weights_path="weights/thermal_detector.pt",
            canthus_weights_path="weights/thermal_canthus_yolo.pt",
            repo_dir="thermal-canthus-detector_new",
        )

    if "F_tfake_mesh" in ACTIVE_MODELS:
        reg["F_tfake_mesh"].load()


def load_ground_truth(gt_csv_path):
    rows = []
    with open(gt_csv_path, newline="") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    return rows


def dist(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def evaluate_side(pred_pt, gt_x, gt_y, gt_visible):
    """
    Returns one of: 'TP', 'FP', 'FN', 'TN', plus pixel error (or None).
    TN = correctly reported nothing for an occluded side.
    """
    gt_visible = bool(int(gt_visible)) if gt_visible not in ("", None) else False

    if gt_visible:
        if pred_pt is None:
            return "FN", None
        gt_pt = (float(gt_x), float(gt_y))
        err = dist(pred_pt, gt_pt)
        return ("TP", err) if err <= MATCH_PIXEL_THRESHOLD else ("FN", err)
    else:
        return ("TN", None) if pred_pt is None else ("FP", None)


def distance_bucket(distance_m):
    d = float(distance_m)
    edges = [1.5, 1.75, 2.0, 2.25, 2.5]
    return min(edges, key=lambda e: abs(e - d))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gt", required=True, help="Path to ground-truth annotations CSV")
    ap.add_argument("--images-dir", required=True, help="Directory containing the image files")
    ap.add_argument("--out", default="report.csv", help="Output metrics CSV")
    args = ap.parse_args()

    setup_models()
    gt_rows = load_ground_truth(args.gt)
    print(f"Loaded {len(gt_rows)} ground-truth rows.")

    # raw per-frame results: model -> list of dicts
    raw_results = defaultdict(list)
    latencies = defaultdict(list)

    for i, row in enumerate(gt_rows):
        img_path = Path(args.images_dir) / row["image_path"]
        bgr = cv2.imread(str(img_path))
        if bgr is None:
            print(f"WARNING: could not read {img_path}, skipping")
            continue

        bucket = distance_bucket(row["distance_m"])
        occlusion = row.get("occlusion", "unknown")

        for model_name in ACTIVE_MODELS:
            module = MODEL_REGISTRY[model_name]
            t0 = time.perf_counter()
            try:
                result = module.detect(bgr)
            except Exception as exc:
                print(f"[{model_name}] detect() failed on {row['image_id']}: {exc}")
                continue
            latencies[model_name].append(time.perf_counter() - t0)

            left_outcome, left_err = evaluate_side(
                result.left, row.get("gt_left_x"), row.get("gt_left_y"), row.get("gt_left_visible"))
            right_outcome, right_err = evaluate_side(
                result.right, row.get("gt_right_x"), row.get("gt_right_y"), row.get("gt_right_visible"))

            raw_results[model_name].append({
                "image_id": row["image_id"], "distance_bucket": bucket, "occlusion": occlusion,
                "left_outcome": left_outcome, "left_err": left_err,
                "right_outcome": right_outcome, "right_err": right_err,
            })

        if (i + 1) % 25 == 0:
            print(f"  ...{i+1}/{len(gt_rows)} frames processed")

    write_report(raw_results, latencies, args.out)


def write_report(raw_results, latencies, out_path):
    summary_rows = []

    for model_name, records in raw_results.items():
        groups = defaultdict(list)
        for r in records:
            groups[(r["distance_bucket"], r["occlusion"])].append(r)

        for (bucket, occlusion), recs in sorted(groups.items()):
            tp = fp = fn = tn = 0
            errs = []
            for r in recs:
                for side in ("left", "right"):
                    outcome = r[f"{side}_outcome"]
                    err = r[f"{side}_err"]
                    if outcome == "TP":
                        tp += 1
                        if err is not None:
                            errs.append(err)
                    elif outcome == "FP":
                        fp += 1
                    elif outcome == "FN":
                        fn += 1
                    elif outcome == "TN":
                        tn += 1

            precision = tp / (tp + fp) if (tp + fp) else float("nan")
            recall = tp / (tp + fn) if (tp + fn) else float("nan")
            f1 = (2 * precision * recall / (precision + recall)
                  if (precision == precision and recall == recall and (precision + recall) > 0)
                  else float("nan"))
            mean_err = float(np.mean(errs)) if errs else float("nan")
            occlusion_false_positive_rate = fp / (fp + tn) if (fp + tn) else float("nan")

            summary_rows.append({
                "model": model_name,
                "distance_bucket_m": bucket,
                "occlusion_condition": occlusion,
                "n_frames": len(recs),
                "precision": round(precision, 3) if precision == precision else "",
                "recall": round(recall, 3) if recall == recall else "",
                "f1": round(f1, 3) if f1 == f1 else "",
                "mean_pixel_error": round(mean_err, 2) if mean_err == mean_err else "",
                "occluded_side_false_positive_rate": (
                    round(occlusion_false_positive_rate, 3)
                    if occlusion_false_positive_rate == occlusion_false_positive_rate else ""
                ),
                "mean_latency_s": (
                    round(float(np.mean(latencies[model_name])), 4) if latencies.get(model_name) else ""
                ),
            })

    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()) if summary_rows else [])
        writer.writeheader()
        writer.writerows(summary_rows)

    print(f"\nReport written to {out_path}")
    print("\nKey column to look at first: occluded_side_false_positive_rate")
    print("  -> near 0 for occlusion-correct models, near 1 for models that always report both sides.\n")

    for row in summary_rows:
        print(row)


if __name__ == "__main__":
    main()
