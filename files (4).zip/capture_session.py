"""
capture_session.py
===================
Guided capture tool for building the distance x occlusion x subject test set.

Workflow:
  1. Mark floor distances at 1.5 / 1.75 / 2.0 / 2.25 / 2.5 m (or edit DISTANCES below).
  2. Run this script. It prompts you through each (subject, distance, occlusion)
     combination, lets you preview live, and press SPACE to capture a stable frame
     (reuses the same stability-wait / multi-frame-average logic as your main scripts
     so capture conditions match what your detectors will see in deployment).
  3. Each capture saves:
       - <image_id>.png        -> IronRed BGR palette image (what detectors consume)
       - <image_id>_y16.npy    -> raw y16 thermal frame (for ground-truth temp checks later)
     and appends one row to metadata.csv with the known distance/occlusion/subject
     labels (everything except the actual canthus pixel coordinates, which you fill
     in during annotation).

Run:
    python capture_session.py --port /dev/ttyACM0 --subject alice --out ./captures
"""
import sys
import os
import csv
import time
import argparse
from datetime import datetime
from pathlib import Path
from collections import deque

sys.path.insert(0, 'build/python')
import guideusb2 as g
import numpy as np
import cv2

DISTANCES_M   = [1.5, 1.75, 2.0, 2.25, 2.5]
OCCLUSIONS    = ["none", "left_occluded", "right_occluded"]   # extend as needed
STABILITY_WARMUP  = 1.5
STABILITY_THRESH  = 0.5
STABILITY_CHECKS  = 5
N_AVG             = 10

linear_cal  = g.CameraLinearCal()
last_status = [None]
last_frame  = [None]


def on_frame(frame):
    last_frame[0] = frame
    if last_status[0] is not None:
        try:
            linear_cal.fit(frame.y16, last_status[0])
        except Exception:
            pass


def wait_stable(timeout=8.0):
    time.sleep(STABILITY_WARMUP)
    recent = deque(maxlen=STABILITY_CHECKS)
    t0 = time.time()
    while time.time() - t0 < timeout:
        if last_frame[0] is not None and linear_cal.ready():
            temps = linear_cal.decode(last_frame[0].y16)
            recent.append(float(temps.max()))
            if len(recent) == STABILITY_CHECKS and (max(recent) - min(recent)) < STABILITY_THRESH:
                return True
        time.sleep(0.2)
    return False


def capture_frame():
    frozen = last_frame[0]
    if frozen is None or not linear_cal.ready():
        return None, None, None
    decoded = []
    for _ in range(N_AVG):
        try:
            decoded.append(linear_cal.decode(frozen.y16))
        except Exception:
            pass
    if not decoded:
        return None, None, None
    temps_avg = np.mean(decoded, axis=0)
    rgb = g.apply_palette(frozen.y16, g.Palette.IronRed, g.PaletteOptions(auto_range=True))
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    return frozen, temps_avg, bgr


def init_metadata(path):
    if not os.path.exists(path):
        with open(path, "w", newline="") as f:
            csv.writer(f).writerow([
                "image_id", "image_path", "y16_path",
                "subject_id", "distance_m", "occlusion",
                "captured_at"
            ])


def append_metadata(path, row):
    with open(path, "a", newline="") as f:
        csv.writer(f).writerow(row)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", default="/dev/ttyACM0")
    ap.add_argument("--subject", required=True, help="Subject ID label, e.g. 'alice'")
    ap.add_argument("--out", default="./captures")
    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    meta_path = out_dir / "metadata.csv"
    init_metadata(meta_path)

    cam = g.Camera(g.DeviceInfo(serial_port=args.port))
    cam.configure_thermography(g.ThermographyConfig(emissivity=98))
    cam.start(on_frame)
    print("Warming up 5s...")
    time.sleep(5)

    print("Calibrating...")
    for _ in range(20):
        try:
            s = cam.serial().query_temp_status(retries=2, wait_seconds=1.5)
            if s:
                last_status[0] = s
                if last_frame[0] is not None:
                    linear_cal.fit(last_frame[0].y16, s)
                break
        except Exception:
            pass
        time.sleep(1)

    if not linear_cal.ready():
        print("Calibration failed.")
        cam.stop()
        sys.exit(1)

    cv2.namedWindow("Capture", cv2.WINDOW_NORMAL)
    shot_count = 0

    for distance in DISTANCES_M:
        for occlusion in OCCLUSIONS:
            print(f"\n=== Subject:{args.subject}  Distance:{distance}m  Occlusion:{occlusion} ===")
            print("Position subject, then press SPACE to capture, R to retake, N to skip.")
            captured = False
            while not captured:
                if last_frame[0] is None or not linear_cal.ready():
                    time.sleep(0.05)
                    continue
                preview = cv2.cvtColor(
                    g.apply_palette(last_frame[0].y16, g.Palette.IronRed,
                                    g.PaletteOptions(auto_range=True)),
                    cv2.COLOR_RGB2BGR)
                cv2.putText(preview, f"{args.subject} | {distance}m | {occlusion}",
                            (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                cv2.imshow("Capture", preview)
                key = cv2.waitKey(30) & 0xFF

                if key == ord('n'):
                    print("Skipped.")
                    break
                if key == ord(' '):
                    print("Waiting for stable scene...")
                    wait_stable()
                    frozen, temps_avg, bgr = capture_frame()
                    if frozen is None:
                        print("Capture failed, retry.")
                        continue

                    shot_count += 1
                    image_id = f"{args.subject}_{distance}m_{occlusion}_{shot_count:03d}"
                    img_path = out_dir / f"{image_id}.png"
                    y16_path = out_dir / f"{image_id}_y16.npy"
                    cv2.imwrite(str(img_path), bgr)
                    np.save(str(y16_path), frozen.y16)

                    append_metadata(meta_path, [
                        image_id, str(img_path), str(y16_path),
                        args.subject, distance, occlusion,
                        datetime.now().isoformat()
                    ])
                    print(f"Saved {image_id}")
                    captured = True

    cam.stop()
    cv2.destroyAllWindows()
    print(f"\nDone. Metadata: {meta_path}")
    print("Next step: run annotate_tool.html on the images in this folder.")


if __name__ == "__main__":
    main()
