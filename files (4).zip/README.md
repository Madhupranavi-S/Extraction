# Canthus Detection — Quantitative Evaluation Toolkit

Implements the plan: capture a controlled distance x occlusion test set, annotate
ground truth, run all six pipelines against it, and get a metrics table that
actually answers "which model wins" instead of reasoning from code alone.

## Workflow order

### 1. Capture: `capture_session.py`
Run on the machine connected to the camera:
```
python capture_session.py --port /dev/ttyACM0 --subject alice --out ./captures
```
- Walks you through every (distance x occlusion) combination for one subject.
- Re-run with a different `--subject` for each person in your test set.
- Saves `<image_id>.png` (the BGR palette image, exactly what every detector
  consumes) + `<image_id>_y16.npy` (raw thermal, for temperature ground truth
  later if you want it) + appends a row to `captures/metadata.csv`.
- Edit `DISTANCES_M` / `OCCLUSIONS` at the top of the script if your protocol
  needs different values.

Recommended: 5–8+ subjects x 5 distances x 3 occlusion conditions ≈ 75–120+
images minimum, more if you can.

### 2. Annotate: `annotate_tool.html`
Open this file directly in a browser (no install, no server needed).
- Click "Load images" and select the folder of captured `.png` files.
- For each image: click to place the left canthus (key `1` selects it),
  click again to place the right canthus (key `2`). If a side is occluded,
  click "Occluded" instead of guessing a point — this is the ground truth the
  harness needs to measure occlusion-correctness.
- Press `S` or "Save row & next" to commit and advance.
- When done, "Export annotations.csv" — this matches the schema
  `eval_harness.py` expects.
- Filenames following the pattern from `capture_session.py`
  (`subject_distanceM_occlusion_NNN.png`) auto-fill subject/distance/occlusion
  metadata; otherwise edit the exported CSV by hand to fill those columns.

**Tip:** have a second person independently re-annotate ~10% of images. Compare
their clicked coordinates to yours — that pixel disagreement is your
measurement noise floor. If a model's error is smaller than that, you've hit
the ceiling of what's measurable and shouldn't chase further precision.

### 3. Run the harness: `eval_harness.py`
First, fill in your real weight paths in `setup_models()` inside
`eval_harness.py` (search for `weights/...` placeholders). Models you haven't
wired up yet can be removed from `ACTIVE_MODELS` so the rest still run.

```
python eval_harness.py --gt ./captures/annotations.csv --images-dir ./captures --out report.csv
```

This runs all six wrapped detectors (`detectors/model_a_*.py` ...
`model_f_*.py`) against every annotated frame and writes `report.csv` with
one row per (model, distance bucket, occlusion condition):

| column | meaning |
|---|---|
| `precision` / `recall` / `f1` | standard detection metrics per side |
| `mean_pixel_error` | localization error in px, only over correctly-detected points |
| `occluded_side_false_positive_rate` | **the key number** — how often the model reports a point for a side that was actually occluded. Near 0 = occlusion-correct (expected for A/B/C). Near 1 = always reports both regardless of visibility (expected for D/E/F). |
| `mean_latency_s` | average per-frame detect() time — compare B vs C here especially |

### 4. Interpreting results
- Look at `occluded_side_false_positive_rate` first — this is the number that
  separates the architecturally occlusion-correct models from the ones that
  can't be fixed without retraining.
- Among whichever models pass that filter, compare `mean_pixel_error` and
  `recall` by `distance_bucket_m` — this is where you'll see A's well-being
  fall apart at range while B/C hold up.
- `mean_latency_s` is the final tiebreaker between survivors (expected: B
  slower due to tiling, C cheaper but contingent on stage-1 face-detector
  reliability — check C's `recall` specifically at the farthest bucket, since
  a missed face there silently produces a false negative on both sides at
  once).

## Notes / things to double check before trusting the numbers
- `detectors/model_e_two_stage_keypoint.py` calls an external repo's
  `load_models()`/`detect()` you haven't shown me the internals of — if
  certainty about its occlusion behavior matters, open
  `thermal-canthus-detector_new/detect_canthus.py` directly and check whether
  `detect()` does anything with per-keypoint confidence before returning.
- `MATCH_PIXEL_THRESHOLD` (default 8px) in `eval_harness.py` decides what
  counts as "close enough" to ground truth. Set it based on your annotator
  disagreement test (step 2's tip) rather than leaving the default.
- All six detectors are run on the *same saved frames*, not live re-captures —
  this is intentional so comparisons are apples-to-apples and not confounded
  by scene drift between runs.
