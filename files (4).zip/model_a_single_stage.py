"""
model_a_single_stage.py
Single-stage detect.pt, run directly on the full frame (no SAHI). Independent
left/right classes with independent confidence -> occlusion-correct by
architecture. Expected to fail at distance due to resolution loss.
"""
import numpy as np
from ultralytics import YOLO
from .common import DetectionResult

CLASS_LEFT, CLASS_RIGHT = 0, 1
CONF_THRESH = 0.25
IMG_SIZE = 320

_model = None


def load(weights_path: str):
    global _model
    _model = YOLO(str(weights_path))


def detect(bgr: np.ndarray) -> DetectionResult:
    if _model is None:
        raise RuntimeError("Call load(weights_path) before detect().")

    results = _model(bgr, imgsz=IMG_SIZE, conf=CONF_THRESH, verbose=False)[0]
    left_pt = right_pt = None
    left_conf = right_conf = 0.0

    if results.boxes is not None and len(results.boxes) > 0:
        boxes = results.boxes.xyxy.cpu().numpy()
        clss = results.boxes.cls.cpu().numpy().astype(int)
        confs = results.boxes.conf.cpu().numpy()
        for box, cls_id, conf in zip(boxes, clss, confs):
            cx = float((box[0] + box[2]) / 2.0)
            cy = float((box[1] + box[3]) / 2.0)
            if cls_id == CLASS_LEFT and conf > left_conf:
                left_pt, left_conf = (cx, cy), float(conf)
            elif cls_id == CLASS_RIGHT and conf > right_conf:
                right_pt, right_conf = (cx, cy), float(conf)

    return DetectionResult(left_pt, right_pt, left_conf, right_conf)
