#!/usr/bin/env python3
"""
eval_harness.py
================
Runs every ACTIVE detector wrapper in detectors/ against an annotated set
of saved frames, and writes report.csv with one row per
(model, distance_bucket_m, occlusion_condition).

EXPECTED DIRECTORY LAYOUT
--------------------------
your_project/
  eval_harness.py          <- this file
  detectors/
    detector_singlestage_sahi_v1.py
    detector_singlestage_sahi_v2_cascade.py
    detector_twostage_fixedzoom.py
    detector_twostage_adaptivezoom.py
    detector_tfake_landmark.py
  weights/
    detect.pt               <- EDIT MODEL_REGISTRY below to point at your real files
    thermal_detector.pt
  captures/
    annotations.csv
    <image_id>.png
    <image_id>_y16.npy
    <image_id>_temps.npy     <- OPTIONAL, see "ABOUT temps_c" below

EXPECTED annotations.csv SCHEMA
---------------------------------
One row per annotated frame:

  image_id        - filename stem, matches <image_id>.png in --images-dir
  subject         - subject id (not used in metrics, just passed through)
  distance_m      - numeric distance for this frame; used as the
                    distance_bucket_m grouping key directly (your capture
                    protocol already discretizes distance, so no binning
                    is done here)
  occlusion       - categorical condition label (e.g. "none", "glasses",
                    "mask", ...) from your capture protocol; used as the
                    occlusion_condition grouping key directly
  left_x, left_y  - ground-truth left-canthus pixel coords (blank if
                    left_occluded is true)
  left_occluded   - 1/0, true/false, "occluded"/"" -- whatever your
                    annotate_tool.html exports; parse_bool() below accepts
                    common spellings
  right_x, right_y, right_occluded - same, for the right canthus

If your actual exported column names differ, edit the COL_* constants
just below MATCH_PIXEL_THRESHOLD -- that's the one place they're used.

ABOUT temps_c (only matters for detector_tfake_landmark.py)
--------------------------------------------------------------
detector_tfake_landmark.detect() accepts an optional temps_c array for a
faithful comparison (see that file's docstring for why). If a file named
<image_id>_temps.npy exists next to <image_id>.png in --images-dir, this
harness will load it and pass it to any detector whose detect() signature
accepts a temps_c argument. If you don't have that file, T-FAKE silently
falls back to its (flagged, less faithful) approximation -- nothing here
crashes either way.

HOW A FRAME IS SCORED
-----------------------
For each (model, frame), each side (left/right) is independently
classified by comparing the model's reported point against ground truth:

  ground truth visible + prediction within MATCH_PIXEL_THRESHOLD px -> TP
  ground truth visible + prediction missing                         -> FN
  ground truth visible + prediction present but too far             -> FN + FP
                                                                         (missed the real point AND produced a spurious one)
  ground truth OCCLUDED + prediction present                        -> FP
                                                                         (this is what occluded_side_false_positive_rate counts)
  ground truth OCCLUDED + prediction missing                        -> correct, no counters incremented

precision/recall/f1 pool left+right sides together for a (model, bucket)
group. mean_pixel_error averages only over TP cases. mean_latency_s times
one full detect() call per frame (both sides), not per side.
"""

import argparse
import csv
import importlib
import inspect
import math
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import cv2

# =============================================================
# TUNABLES
# =============================================================
# Calibrate this against your annotator-disagreement test (README step 2's
# tip) rather than trusting the default. Overridable at the command line
# with --match-threshold so you don't have to edit source to experiment.
MATCH_PIXEL_THRESHOLD = 8.0

# Column names in your annotations.csv -- edit these if your
# annotate_tool.html export uses different headers.
COL_IMAGE_ID       = "image_id"
COL_SUBJECT        = "subject"
COL_DISTANCE_M     = "distance_m"
COL_OCCLUSION      = "occlusion"
COL_LEFT_X         = "left_x"
COL_LEFT_Y         = "left_y"
COL_LEFT_OCCLUDED  = "left_occluded"
COL_RIGHT_X        = "right_x"
COL_RIGHT_Y        = "right_y"
COL_RIGHT_OCCLUDED = "right_occluded"

# =============================================================
# MODEL REGISTRY -- EDIT THIS
# =============================================================
# weights value is passed straight through to that module's load_models().
# - single-stage detectors expect a single path (str/Path) or None to
#   auto-detect.
# - two-stage detectors expect a dict {"face": ..., "canthus": ...} or
#   None to auto-detect.
# - detector_tfake_landmark.py ignores weights entirely (the tfan package
#   resolves its own).
MODEL_REGISTRY = {
    "singlestage_sahi_v1": {
        "module": "detector_singlestage_sahi_v1",
        "weights": "weights/detect.pt",  # <-- EDIT ME
    },
    "singlestage_sahi_v2_cascade": {
        "module": "detector_singlestage_sahi_v2_cascade",
        "weights": "weights/detect.pt",  # <-- EDIT ME (same canthus weights, different slicing)
    },
    "twostage_fixedzoom": {
        "module": "detector_twostage_fixedzoom",
        "weights": {
            "face": "weights/thermal_detector.pt",  # <-- EDIT ME
            "canthus": "weights/detect.pt",          # <-- EDIT ME
        },
    },
    "twostage_adaptivezoom": {
        "module": "detector_twostage_adaptivezoom",
        "weights": {
            "face": "weights/thermal_detector.pt",  # <-- EDIT ME
            "canthus": "weights/detect.pt",          # <-- EDIT ME
        },
    },
    "tfake_landmark": {
        "module": "detector_tfake_landmark",
        "weights": None,
    },
}

# Remove/comment out any entry above you haven't wired up real weights for
# yet -- the rest will still run.
ACTIVE_MODELS = list(MODEL_REGISTRY.keys())


# =============================================================
# MODEL LOADING
# =============================================================
def setup_models(detectors_dir: Path, active_models=None):
    """Import + load_models() every active detector. Returns {name: (module, model_obj)}."""
    sys.path.insert(0, str(detectors_dir))

    names = active_models if active_models is not None else ACTIVE_MODELS
    loaded = {}
    for name in names:
        if name not in MODEL_REGISTRY:
            print(f"WARNING: '{name}' not found in MODEL_REGISTRY -- skipping")
            continue
        cfg = MODEL_REGISTRY[name]
        print(f"Loading {name} ({cfg['module']}) ...")
        try:
            mod = importlib.import_module(cfg["module"])
            model_obj = mod.load_models(cfg.get("weights"))
        except Exception as e:
            print(f"  FAILED to load {name}: {e}")
            print(f"  (skipping this model for the rest of the run)")
            continue
        loaded[name] = (mod, model_obj)
        print(f"  OK")
    return loaded


# =============================================================
# GROUND TRUTH / IMAGE LOADING
# =============================================================
def parse_bool(s) -> bool:
    if s is None:
        return False
    return str(s).strip().lower() in ("1", "true", "yes", "y", "occluded")


def parse_float_or_none(s):
    if s is None or str(s).strip() == "":
        return None
    return float(s)


def load_ground_truth(gt_path: Path):
    with open(gt_path, newline="") as f:
        return list(csv.DictReader(f))


def load_image(images_dir: Path, image_id: str):
    for ext in (".png", ".jpg", ".jpeg"):
        p = images_dir / f"{image_id}{ext}"
        if p.exists():
            img = cv2.imread(str(p))
            if img is not None:
                return img
    raise FileNotFoundError(f"no image found for image_id='{image_id}' in {images_dir}")


def maybe_load_temps(images_dir: Path, image_id: str):
    p = images_dir / f"{image_id}_temps.npy"
    if p.exists():
        return np.load(str(p))
    return None


# =============================================================
# DETECTION + SCORING
# =============================================================
def call_detect(mod, model_obj, bgr, temps_c):
    """Call this detector's detect(), passing temps_c through only if it accepts it."""
    sig = inspect.signature(mod.detect)
    kwargs = {}
    if temps_c is not None and "temps_c" in sig.parameters:
        kwargs["temps_c"] = temps_c

    t0 = time.perf_counter()
    result = mod.detect(model_obj, bgr, **kwargs)
    dt = time.perf_counter() - t0
    return result, dt


def euclidean(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def classify_side(gt_pt, gt_occluded: bool, pred_pt):
    """
    Returns (outcome, pixel_error_or_None) where outcome is one of:
    "tp", "fn", "fn_fp_localization", "fp_occlusion", "tn_occlusion"
    """
    gt_present = (not gt_occluded) and (gt_pt is not None)
    pred_present = pred_pt is not None

    if gt_present and pred_present:
        d = euclidean(gt_pt, pred_pt)
        if d <= MATCH_PIXEL_THRESHOLD:
            return "tp", d
        return "fn_fp_localization", d
    if gt_present and not pred_present:
        return "fn", None
    if (not gt_present) and pred_present:
        return "fp_occlusion", None
    return "tn_occlusion", None


def new_bucket():
    return {
        "tp": 0, "fn": 0, "fp": 0,
        "occluded_total": 0, "occluded_fp": 0,
        "pixel_errors": [], "latencies": [],
    }


def safe_div(a, b):
    return (a / b) if b else None


def fmt(x, ndigits=4):
    return "" if x is None or (isinstance(x, float) and math.isnan(x)) else round(x, ndigits)


# =============================================================
# MAIN
# =============================================================
def main():
    global MATCH_PIXEL_THRESHOLD

    ap = argparse.ArgumentParser(description="Quantitative canthus-detector evaluation harness")
    ap.add_argument("--gt", required=True, help="Path to annotations.csv")
    ap.add_argument("--images-dir", required=True, help="Folder containing <image_id>.png frames")
    ap.add_argument("--out", default="report.csv", help="Output report CSV path")
    ap.add_argument("--match-threshold", type=float, default=MATCH_PIXEL_THRESHOLD,
                     help="Pixel distance within which a detection counts as correct "
                          "(calibrate against your annotator-disagreement test)")
    ap.add_argument("--models", default=None,
                     help="Comma-separated subset of ACTIVE_MODELS to run "
                          "(default: everything in ACTIVE_MODELS)")
    args = ap.parse_args()

    MATCH_PIXEL_THRESHOLD = args.match_threshold

    gt_path = Path(args.gt)
    images_dir = Path(args.images_dir)
    detectors_dir = Path(__file__).parent / "detectors"

    active = args.models.split(",") if args.models else None

    gt_rows = load_ground_truth(gt_path)
    print(f"Loaded {len(gt_rows)} annotated frames from {gt_path}")

    models = setup_models(detectors_dir, active_models=active)
    if not models:
        print("No models loaded successfully -- nothing to evaluate. Exiting.")
        sys.exit(1)
    print(f"Active models: {list(models.keys())}\n")

    # stats[model_name][(distance_m, occlusion)] = bucket dict
    stats = defaultdict(lambda: defaultdict(new_bucket))

    n_frames_seen = 0
    n_frames_skipped = 0

    for i, row in enumerate(gt_rows):
        image_id = Path(row[COL_IMAGE_ID]).stem
        distance_m = row.get(COL_DISTANCE_M, "")
        occlusion = row.get(COL_OCCLUSION, "") or "none"

        try:
            bgr = load_image(images_dir, image_id)
        except FileNotFoundError as e:
            print(f"WARNING: {e} -- skipping row {i}")
            n_frames_skipped += 1
            continue

        temps_c = maybe_load_temps(images_dir, image_id)

        gt_left_occluded = parse_bool(row.get(COL_LEFT_OCCLUDED))
        gt_right_occluded = parse_bool(row.get(COL_RIGHT_OCCLUDED))

        lx, ly = parse_float_or_none(row.get(COL_LEFT_X)), parse_float_or_none(row.get(COL_LEFT_Y))
        rx, ry = parse_float_or_none(row.get(COL_RIGHT_X)), parse_float_or_none(row.get(COL_RIGHT_Y))
        gt_left = None if (lx is None or ly is None) else (lx, ly)
        gt_right = None if (rx is None or ry is None) else (rx, ry)

        key = (distance_m, occlusion)
        n_frames_seen += 1

        for name, (mod, model_obj) in models.items():
            try:
                result, dt = call_detect(mod, model_obj, bgr, temps_c)
            except Exception as e:
                print(f"ERROR running {name} on {image_id}: {e}")
                continue

            bucket = stats[name][key]
            bucket["latencies"].append(dt)

            for pred_pt, gt_pt, gt_occluded in (
                (result.get("left_pt"), gt_left, gt_left_occluded),
                (result.get("right_pt"), gt_right, gt_right_occluded),
            ):
                outcome, dist = classify_side(gt_pt, gt_occluded, pred_pt)

                if gt_occluded:
                    bucket["occluded_total"] += 1

                if outcome == "tp":
                    bucket["tp"] += 1
                    bucket["pixel_errors"].append(dist)
                elif outcome == "fn":
                    bucket["fn"] += 1
                elif outcome == "fn_fp_localization":
                    bucket["fn"] += 1
                    bucket["fp"] += 1
                elif outcome == "fp_occlusion":
                    bucket["fp"] += 1
                    bucket["occluded_fp"] += 1
                # "tn_occlusion": correctly silent -- nothing to increment

        if (i + 1) % 25 == 0:
            print(f"... processed {i + 1}/{len(gt_rows)} frames")

    print(f"\nDone. {n_frames_seen} frames scored, {n_frames_skipped} skipped (missing image).")

    # ---- aggregate into report rows ----
    out_rows = []
    for name, buckets in stats.items():
        for (distance_m, occlusion), b in buckets.items():
            tp, fn, fp = b["tp"], b["fn"], b["fp"]
            precision = safe_div(tp, tp + fp)
            recall = safe_div(tp, tp + fn)
            f1 = (safe_div(2 * precision * recall, precision + recall)
                  if (precision is not None and recall is not None and (precision + recall) > 0)
                  else None)
            mean_pixel_error = (sum(b["pixel_errors"]) / len(b["pixel_errors"])
                                 if b["pixel_errors"] else None)
            occluded_fp_rate = safe_div(b["occluded_fp"], b["occluded_total"])
            mean_latency = (sum(b["latencies"]) / len(b["latencies"])
                             if b["latencies"] else None)

            out_rows.append({
                "model": name,
                "distance_bucket_m": distance_m,
                "occlusion_condition": occlusion,
                "n_frames": len(b["latencies"]),
                "precision": fmt(precision),
                "recall": fmt(recall),
                "f1": fmt(f1),
                "mean_pixel_error": fmt(mean_pixel_error, 3),
                "occluded_side_false_positive_rate": fmt(occluded_fp_rate),
                "mean_latency_s": fmt(mean_latency, 5),
            })

    out_rows.sort(key=lambda r: (r["model"], str(r["distance_bucket_m"]), str(r["occlusion_condition"])))

    out_path = Path(args.out)
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "model", "distance_bucket_m", "occlusion_condition", "n_frames",
            "precision", "recall", "f1", "mean_pixel_error",
            "occluded_side_false_positive_rate", "mean_latency_s",
        ])
        writer.writeheader()
        writer.writerows(out_rows)

    print(f"Wrote {len(out_rows)} rows to {out_path}")


if __name__ == "__main__":
    main()
